# ABOUT
- The following directory contains all submission files
- A zipped file of the used project repository, `lib.zip`, is also provided for reference on workflow
    - This was included in case `.dat` or other files must be examined further